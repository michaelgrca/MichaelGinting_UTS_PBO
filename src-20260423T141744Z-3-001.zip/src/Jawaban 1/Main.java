import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Perusahaan perusahaan = new Perusahaan();
        int pilihan;

        System.out.println("==============================================");
        System.out.println("   SISTEM MANAJEMEN DATA KARYAWAN");
        System.out.println("==============================================");

        do {
            System.out.println("\n--- MENU UTAMA ---");
            System.out.println("1. Tambah Karyawan");
            System.out.println("2. Hapus Karyawan");
            System.out.println("3. Ubah Posisi Karyawan");
            System.out.println("4. Ubah Gaji Karyawan");
            System.out.println("5. Tampilkan Semua Karyawan");
            System.out.println("6. Cari Karyawan Berdasarkan ID");
            System.out.println("7. Laporan Total Gaji Perusahaan");
            System.out.println("0. Keluar");
            System.out.print("Pilihan Anda: ");
            pilihan = scanner.nextInt();
            scanner.nextLine();

            switch (pilihan) {
                case 1:
                    System.out.println("\n--- TAMBAH KARYAWAN ---");
                    System.out.print("Masukkan ID     : ");
                    String id = scanner.nextLine();
                    System.out.print("Masukkan Nama   : ");
                    String nama = scanner.nextLine();
                    System.out.print("Masukkan Posisi : ");
                    String posisi = scanner.nextLine();
                    System.out.print("Masukkan Gaji   : ");
                    double gaji = scanner.nextDouble();

                    
                    if (gaji < 0) {
                        System.out.println("[ERROR] Gaji tidak boleh bernilai negatif!");
                    } else {
                        Karyawan baru = new Karyawan(id, nama, posisi, gaji);
                        perusahaan.tambahKaryawan(baru);
                    }
                    break;

                case 2:
                    System.out.println("\n--- HAPUS KARYAWAN ---");
                    System.out.print("Masukkan ID karyawan yang ingin dihapus: ");
                    String idHapus = scanner.nextLine();
                    perusahaan.hapusKaryawan(idHapus);
                    break;

                case 3:
                    System.out.println("\n--- UBAH POSISI KARYAWAN ---");
                    System.out.print("Masukkan ID karyawan  : ");
                    String idPosisi = scanner.nextLine();
                    System.out.print("Masukkan posisi baru  : ");
                    String posisiBaru = scanner.nextLine();
                    perusahaan.ubahPosisi(idPosisi, posisiBaru);
                    break;

                case 4:
                    System.out.println("\n--- UBAH GAJI KARYAWAN ---");
                    System.out.print("Masukkan ID karyawan : ");
                    String idGaji = scanner.nextLine();
                    System.out.print("Masukkan gaji baru   : ");
                    double gajiBaru = scanner.nextDouble();
                    perusahaan.ubahGaji(idGaji, gajiBaru);
                    break;

                case 5:
                    System.out.println("\n--- DAFTAR SELURUH KARYAWAN ---");
                    perusahaan.tampilkanSemuaKaryawan();
                    break;

                case 6:
                    System.out.println("\n--- CARI KARYAWAN ---");
                    System.out.print("Masukkan ID karyawan: ");
                    String idCari = scanner.nextLine();
                    Karyawan hasil = perusahaan.cariKaryawan(idCari);
                    if (hasil != null) {
                        System.out.println("Karyawan ditemukan:");
                        System.out.println("  ID     : " + hasil.getId());
                        System.out.println("  Nama   : " + hasil.getNama());
                        System.out.println("  Posisi : " + hasil.getPosisi());
                        System.out.println("  Gaji   : Rp " + String.format("%,.2f", hasil.getGaji()));
                    } else {
                        System.out.println("[ERROR] Karyawan dengan ID " + idCari + " tidak ditemukan.");
                    }
                    break;

                case 7:
                    System.out.println();
                    perusahaan.tampilkanLaporanGaji();
                    break;

                case 0:
                    System.out.println("\nTerima kasih telah menggunakan sistem ini. Sampai jumpa!");
                    break;

                default:
                    System.out.println("[ERROR] Pilihan tidak valid! Silakan pilih menu 0-7.");
            }
        } while (pilihan != 0);

        scanner.close();
    }
}
