import java.util.ArrayList;

public class Perusahaan {
    private ArrayList<Karyawan> daftarKaryawan;

    public Perusahaan() {
        daftarKaryawan = new ArrayList<>();
    }

    public void tambahKaryawan(Karyawan karyawan) {
        if (cariKaryawan(karyawan.getId()) != null) {
            System.out.println("[ERROR] Gagal menambahkan! ID " + karyawan.getId() + " sudah terdaftar.");
            return;
        }
        daftarKaryawan.add(karyawan);
        System.out.println("[SUKSES] Karyawan " + karyawan.getNama() + " berhasil ditambahkan.");
    }

    public void hapusKaryawan(String id) {
        Karyawan karyawan = cariKaryawan(id);
        if (karyawan == null) {
            System.out.println("[ERROR] Gagal menghapus! Karyawan dengan ID " + id + " tidak ditemukan.");
            return;
        }
        daftarKaryawan.remove(karyawan);
        System.out.println("[SUKSES] Karyawan " + karyawan.getNama() + " (ID: " + id + ") berhasil dihapus.");
    }

    public void ubahPosisi(String id, String posisiBaru) {
        Karyawan karyawan = cariKaryawan(id);
        if (karyawan == null) {
            System.out.println("[ERROR] Gagal mengubah posisi! Karyawan dengan ID " + id + " tidak ditemukan.");
            return;
        }
        String posisiLama = karyawan.getPosisi();
        karyawan.setPosisi(posisiBaru);
        System.out.println("[SUKSES] Posisi " + karyawan.getNama() + " diubah dari " + posisiLama + " menjadi " + posisiBaru + ".");
    }

    public void ubahGaji(String id, double gajiBaru) {
        Karyawan karyawan = cariKaryawan(id);
        if (karyawan == null) {
            System.out.println("[ERROR] Gagal mengubah gaji! Karyawan dengan ID " + id + " tidak ditemukan.");
            return;
        }
        if (gajiBaru < 0) {
            System.out.println("[ERROR] Gagal mengubah gaji! Gaji tidak boleh bernilai negatif.");
            return;
        }
        karyawan.setGaji(gajiBaru);
        System.out.println("[SUKSES] Gaji " + karyawan.getNama() + " berhasil diubah menjadi Rp " + String.format("%,.2f", gajiBaru) + ".");
    }

    public void tampilkanSemuaKaryawan() {
        if (daftarKaryawan.isEmpty()) {
            System.out.println("[INFO] Belum ada data karyawan yang terdaftar.");
            return;
        }
        System.out.println("+" + "-".repeat(10) + "+" + "-".repeat(22) + "+" + "-".repeat(20) + "+" + "-".repeat(19) + "+");
        System.out.printf("| %-8s | %-20s | %-18s | %-17s |%n", "ID", "Nama", "Posisi", "Gaji");
        System.out.println("+" + "-".repeat(10) + "+" + "-".repeat(22) + "+" + "-".repeat(20) + "+" + "-".repeat(19) + "+");
        for (Karyawan k : daftarKaryawan) {
            System.out.println(k);
        }
        System.out.println("+" + "-".repeat(10) + "+" + "-".repeat(22) + "+" + "-".repeat(20) + "+" + "-".repeat(19) + "+");
        System.out.println("Total karyawan: " + daftarKaryawan.size());
    }

    public Karyawan cariKaryawan(String id) {
        for (Karyawan k : daftarKaryawan) {
            if (k.getId().equalsIgnoreCase(id)) {
                return k;
            }
        }
        return null;
    }

    public void tampilkanLaporanGaji() {
        if (daftarKaryawan.isEmpty()) {
            System.out.println("[INFO] Belum ada data karyawan untuk dihitung.");
            return;
        }
        double totalGaji = 0;
        for (Karyawan k : daftarKaryawan) {
            totalGaji += k.getGaji();
        }
        System.out.println("========================================");
        System.out.println("     LAPORAN TOTAL GAJI PERUSAHAAN      ");
        System.out.println("========================================");
        System.out.println("Jumlah Karyawan : " + daftarKaryawan.size());
        System.out.println("Total Gaji      : Rp " + String.format("%,.2f", totalGaji));
        System.out.println("========================================");
    }
}
