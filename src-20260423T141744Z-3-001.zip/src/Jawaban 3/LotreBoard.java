import java.util.Random;

public class LotreBoard {
    private static final int BARIS = 4;
    private static final int KOLOM = 5;
    private static final int JUMLAH_BOM = 2;

    private char[][] board;
    private boolean[][] revealed;
    private int[][] data;
    private int kotakAmanTerbuka;
    private boolean kenaBot;

    public LotreBoard() {
        board = new char[BARIS][KOLOM];
        revealed = new boolean[BARIS][KOLOM];
        data = new int[BARIS][KOLOM];
        kotakAmanTerbuka = 0;
        kenaBot = false;
        generateBoard();
    }

    public void generateBoard() {
        for (int i = 0; i < BARIS; i++) {
            for (int j = 0; j < KOLOM; j++) {
                board[i][j] = '*';
                revealed[i][j] = false;
                data[i][j] = 0;
            }
        }

        Random random = new Random();
        int bomDipasang = 0;

        while (bomDipasang < JUMLAH_BOM) {
            int r = random.nextInt(BARIS);
            int c = random.nextInt(KOLOM);

            if (data[r][c] == 0) {
                data[r][c] = 1;
                bomDipasang++;
            }
        }
    }

    public void displayBoard() {
        System.out.println();
        System.out.print("     ");
        for (int j = 1; j <= KOLOM; j++) {
            System.out.printf(" %-3d", j);
        }
        System.out.println();

        System.out.print("    +");
        for (int j = 0; j < KOLOM; j++) {
            System.out.print("---+");
        }
        System.out.println();

        for (int i = 0; i < BARIS; i++) {
            System.out.printf(" %2d |", i + 1);
            for (int j = 0; j < KOLOM; j++) {
                System.out.printf(" %c |", board[i][j]);
            }
            System.out.println();

            System.out.print("    +");
            for (int j = 0; j < KOLOM; j++) {
                System.out.print("---+");
            }
            System.out.println();
        }

        int totalAman = (BARIS * KOLOM) - JUMLAH_BOM;
        System.out.println("  Kotak terbuka: " + kotakAmanTerbuka + "/" + totalAman);
    }

    public boolean guess(int row, int col) {
        int r = row - 1;
        int c = col - 1;

        if (r < 0 || r >= BARIS || c < 0 || c >= KOLOM) {
            System.out.println("[ERROR] Posisi di luar papan! Masukkan baris (1-" + BARIS + ") dan kolom (1-" + KOLOM + ").");
            return true;
        }

        if (revealed[r][c]) {
            System.out.println("[INFO] Kotak ini sudah pernah dibuka. Pilih kotak lain.");
            return true;
        }

        revealed[r][c] = true;

        if (data[r][c] == 1) {
            board[r][c] = 'X';
            kenaBot = true;
            return false;
        } else {
            board[r][c] = 'O';
            kotakAmanTerbuka++;
            return true;
        }
    }

    public boolean isGameOver() {
        int totalAman = (BARIS * KOLOM) - JUMLAH_BOM;

        if (kenaBot) {
            return true;
        }
        if (kotakAmanTerbuka >= totalAman) {
            return true;
        }
        return false;
    }

    public boolean isKenaBom() {
        return kenaBot;
    }

    public void revealAll() {
        for (int i = 0; i < BARIS; i++) {
            for (int j = 0; j < KOLOM; j++) {
                if (!revealed[i][j]) {
                    board[i][j] = (data[i][j] == 1) ? 'X' : 'O';
                }
            }
        }
    }

    public int getKotakAmanTerbuka() {
        return kotakAmanTerbuka;
    }
}
