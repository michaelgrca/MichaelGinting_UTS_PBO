import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LotreBoard game = new LotreBoard();

        System.out.println("==============================================");
        System.out.println("         LOTRE GOSOK - ParkirChan Game        ");
        System.out.println("==============================================");
        System.out.println("Aturan:");
        System.out.println("  - Papan berukuran 4x5 (20 kotak)");
        System.out.println("  - 2 kotak berisi BOM, 18 kotak AMAN");
        System.out.println("  - Buka semua kotak aman untuk MENANG");
        System.out.println("  - Kena bom = KALAH!");
        System.out.println("  - Simbol: * = belum dibuka, O = aman, X = bom");

        while (!game.isGameOver()) {
            game.displayBoard();

            System.out.print("\nMasukkan baris  (1-4): ");
            int baris = scanner.nextInt();
            System.out.print("Masukkan kolom (1-5): ");
            int kolom = scanner.nextInt();

            boolean aman = game.guess(baris, kolom);

            if (!aman) {
                System.out.println("\n  ** BOOM! Kamu kena bom! **");
            }
        }

        game.revealAll();
        game.displayBoard();

        System.out.println("\n==============================================");
        if (game.isKenaBom()) {
            System.out.println("         GAME OVER - KAMU KALAH!");
            System.out.println("  Kotak aman yang berhasil dibuka: " + game.getKotakAmanTerbuka() + "/18");
        } else {
            System.out.println("      SELAMAT! KAMU MENANG!");
            System.out.println("  Semua 18 kotak aman berhasil dibuka!");
        }
        System.out.println("==============================================");

        scanner.close();
    }
}
