import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int totalKendaraan = 0;
        double totalPendapatan = 0;
        String lanjut = "";

        System.out.println("==============================================");
        System.out.println("        SISTEM PARKIR PARKIRCHAN");
        System.out.println("==============================================");

        do {
            System.out.println("\n--- PILIH JENIS KENDARAAN ---");
            System.out.println("1. Motor");
            System.out.println("2. Mobil");
            System.out.println("3. Truk");
            System.out.print("Pilihan Anda: ");
            int pilihKendaraan = scanner.nextInt();

            String jenis;
            switch (pilihKendaraan) {
                case 1: jenis = "Motor"; break;
                case 2: jenis = "Mobil"; break;
                case 3: jenis = "Truk";  break;
                default:
                    System.out.println("[ERROR] Pilihan tidak valid!");
                    scanner.nextLine();
                    continue;
            }

            Kendaraan kendaraan = new Kendaraan(jenis);

            System.out.println("\n--- PILIH CARA INPUT DURASI ---");
            System.out.println("1. Input durasi langsung (dalam jam)");
            System.out.println("2. Input jam masuk dan jam keluar");
            System.out.print("Pilihan Anda: ");
            int pilihDurasi = scanner.nextInt();

            switch (pilihDurasi) {
                case 1:
                    System.out.print("Masukkan durasi parkir (jam): ");
                    int durasi = scanner.nextInt();

                    if (durasi <= 0) {
                        System.out.println("[ERROR] Durasi harus lebih dari 0 jam!");
                        scanner.nextLine();
                        continue;
                    }
                    kendaraan.hitungBiaya(durasi);
                    break;

                case 2:
                    System.out.print("Masukkan jam masuk (0-23) : ");
                    int jamMasuk = scanner.nextInt();
                    System.out.print("Masukkan jam keluar (0-23): ");
                    int jamKeluar = scanner.nextInt();

                    if (jamKeluar <= jamMasuk) {
                        System.out.println("[ERROR] Jam keluar harus lebih besar dari jam masuk!");
                        scanner.nextLine();
                        continue;
                    }
                    kendaraan.hitungBiaya(jamMasuk, jamKeluar);
                    break;

                default:
                    System.out.println("[ERROR] Pilihan tidak valid!");
                    scanner.nextLine();
                    continue;
            }

            System.out.println();
            kendaraan.tampilkanRingkasan();

            totalKendaraan++;
            totalPendapatan += kendaraan.getTotalBiaya();

            scanner.nextLine();
            System.out.print("\nTambah kendaraan lagi? (y/n): ");
            lanjut = scanner.nextLine();

        } while (lanjut.equalsIgnoreCase("y"));

        System.out.println("\n==============================================");
        System.out.println("          RINGKASAN AKHIR HARI INI           ");
        System.out.println("==============================================");
        System.out.println("  Total Kendaraan   : " + totalKendaraan + " kendaraan");
        System.out.println("  Total Pendapatan  : Rp " + String.format("%,.0f", totalPendapatan));
        System.out.println("==============================================");
        System.out.println("    Terima kasih telah menggunakan ParkirChan!");

        scanner.close();
    }
}
