public class Kendaraan {
    private String jenisKendaraan;
    private int durasiParkir;
    private double totalBiaya;

    private static final int TARIF_MOTOR = 2000;
    private static final int TARIF_MOBIL = 5000;
    private static final int TARIF_TRUK  = 10000;

    public Kendaraan(String jenisKendaraan) {
        this.jenisKendaraan = jenisKendaraan;
    }

    public void hitungBiaya(int durasi) {
        this.durasiParkir = durasi;
        double biaya = durasi * getTarifPerJam();

        if (durasi > 5) {
            biaya *= 0.9;
        }
        this.totalBiaya = biaya;
    }

    public void hitungBiaya(int jamMasuk, int jamKeluar) {
        int durasi = jamKeluar - jamMasuk;

        if (durasi <= 0) {
            System.out.println("[ERROR] Jam keluar harus lebih besar dari jam masuk!");
            this.durasiParkir = 0;
            this.totalBiaya = 0;
            return;
        }
        hitungBiaya(durasi);
    }

    private int getTarifPerJam() {
        switch (jenisKendaraan.toLowerCase()) {
            case "motor": return TARIF_MOTOR;
            case "mobil": return TARIF_MOBIL;
            case "truk":  return TARIF_TRUK;
            default:      return 0;
        }
    }

    public void tampilkanRingkasan() {
        System.out.println("+--------------------------------------+");
        System.out.println("|        STRUK PARKIR PARKIRCHAN       |");
        System.out.println("+--------------------------------------+");
        System.out.println("  Jenis Kendaraan : " + jenisKendaraan.toUpperCase());
        System.out.println("  Durasi Parkir   : " + durasiParkir + " jam");
        System.out.println("  Tarif/Jam       : Rp " + String.format("%,d", getTarifPerJam()));

        if (durasiParkir > 5) {
            System.out.println("  Diskon 10%      : Berlaku (parkir > 5 jam)");
        }

        System.out.println("  Total Biaya     : Rp " + String.format("%,.0f", totalBiaya));
        System.out.println("+--------------------------------------+");
    }

    public double getTotalBiaya() {
        return totalBiaya;
    }

    public int getDurasiParkir() {
        return durasiParkir;
    }

    public String getJenisKendaraan() {
        return jenisKendaraan;
    }
}
